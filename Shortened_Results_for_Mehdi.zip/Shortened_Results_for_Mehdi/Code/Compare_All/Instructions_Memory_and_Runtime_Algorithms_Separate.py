# Instructions_Memory_and_Runtime_Algorithms_Separate.py
# Thomas Wise
# 10 Aug 2019

import os
import matplotlib.pyplot as plt
import statistics

def getIntVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit():
                started = True;
                val += x;
            elif x != "," and started:
                done = True;
    val = int(val);
    return val;

def getIntVal2(line):
    started1 = False;
    started2 = False;
    done1 = False;
    done2 = False;
    val = '';
    for x in line:
        if not done1:
            if x.isdigit():
                started1 = True;
            elif x != "," and x != "." and started1:
                done1 = True;
        elif not done2:
            if x.isdigit():
                started2 = True;
                val += x;
            elif x != "," and started2:
                done2 = True;
    if val == '':
        return getIntVal(line);
    val = int(val);
    return val;
    
def getFltVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit() or x == '.':
                val += x;
                started = True;
            elif x == ' ' and started:
                done = True;
    val = float(val);
    return val;
    
def parseFile(filename, taskClocks, contextSwitches, cpuMigrations, pageFaults,
                cycles, instructions, branches, branchMisses, runTimes, solver):
    solverNum = -1;
    if solver == "Glucose":
        solverNum = 0;
    elif solver == "Maple_CM":
        solverNum = 1;
    elif solver == "Maple_Glucose":
        solverNum = 2;
    elif solver == "MapleSat":
        solverNum = 3;
    elif solver == "MiniSat":
        solverNum = 4;
        
    f = open(filename);
    f1 = f.readlines();
    f.close();
    started = False;
    
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal2(line);
            started = True;
        elif "instructions" in line and started:
            instructions[index][solverNum].append(getIntVal(line));
        elif "seconds time elapsed" in line and started:
            runTimes[index][solverNum].append(getFltVal(line));
    print(filename);
     
def memParseFile(filename, all_stores, all_loads, solver):
    solverNum = -1;
    if solver == "Glucose":
        solverNum = 0;
    elif solver == "Maple_CM":
        solverNum = 1;
    elif solver == "Maple_Glucose":
        solverNum = 2;
    elif solver == "MapleSat":
        solverNum = 3;
    elif solver == "MiniSat":
        solverNum = 4;
        
    f = open(filename);
    f1 = f.readlines();
    f.close();
    started = False;
    
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal2(line);
            started = True;
        elif "mem_uops_retired.all_loads" in line and started:
            all_loads[index][solverNum].append(getIntVal(line));
        elif "mem_uops_retired.all_stores" in line and started:
            all_stores[index][solverNum].append(getIntVal(line));
    print(filename);
            
def makePlot(l, plot, start, end, size, solverNum):
    for instance in l:
        solved = True;
        for solver in instance:
            if len(solver) != size:
                solved = False;
        if solved:
            if statistics.mean(instance[solverNum]) != 0:
                plot.append(statistics.stdev(instance[solverNum]) / statistics.mean(instance[solverNum]));
            else:
                plot.append(0);

def getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes,
            all_stores, all_loads, solver):
    for filename in os.listdir(solver + "/Perf_Standard/Data/Results"):
        if "slurm" in filename or ".txt.e" in filename or ".out" in filename:
            parseFile(solver + "/Perf_Standard/Data/Results/" + filename, taskClocks,
                        contextSwitches, cpuMigrations, pageFaults,
                        cycles, instructions, branches, branchMisses, runTimes, solver);
    for filename in os.listdir(solver +"/Perf_MEM_UOPS_RETIRED/Data/Results"):
        if "slurm" in filename or ".txt.e" in filename or ".out" in filename:
            memParseFile(solver + "/Perf_MEM_UOPS_RETIRED/Data/Results/" + filename, all_stores, all_loads, solver);
            
start = 0;
end = 399;
instances = end - start + 1;
testsPerInstance = 10;

solvers = ["Glucose", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat"];

taskClocks = [];
contextSwitches = [];
cpuMigrations = [];
pageFaults = [];
cycles = [];
instructions = [];
branches = [];
branchMisses = [];
runTimes = [];
all_stores = [];
all_loads = [];

data = [instructions, runTimes,
        all_stores, all_loads];

for x in range(0, instances):
    for dataType in data:
        dataType.append([]);
        for poop in range(0,5):
            dataType[len(dataType) - 1].append([]);

taskClocksPlot = [];
contextSwitchesPlot = [];
cpuMigrationsPlot = [];
pageFaultsPlot = [];
cyclesPlot = [];
instructionsPlot = [];
branchesPlot = [];
branchMissesPlot = [];
runTimesPlot = [];   
all_storesPlot = [];
all_loadsPlot = [];

dataToPlot = [instructionsPlot, runTimesPlot,
              all_storesPlot, all_loadsPlot];
              
for plot in dataToPlot:
    for x in range(0, 5):
        plot.append([]);

for solver in solvers:
    getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes,
            all_stores, all_loads, solver);
     

index = 0;
for plot in dataToPlot:
    for x in range(0, 5):
        print();
        print("data: " + str(len(data)));
        print("index: " + str(index));
        print("plot: " + str(len(plot)));
        print("x: " + str(x));
        makePlot(data[index], plot[x], start, end, testsPerInstance, x);
    index += 1;

extendedPlotData = [];
for dataType in dataToPlot:
    for plot in dataType:
        extendedPlotData.append(plot);

fig = plt.figure(1, figsize=(9, 6));
ax = fig.add_subplot(111);
bp = ax.boxplot(extendedPlotData);
ax.set_xticklabels(["Glucose Instructions", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat",
                    "Glucose RunTime", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat",
                    "Glucose all_stores", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat",
                    "Glucose all_loads", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat"]);
                    
ax.set_yscale("log");
plt.ylabel("STDEV / Mean");
plt.xticks(rotation=20);
fig.show();
print(len(runTimesPlot));