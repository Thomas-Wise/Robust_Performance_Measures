# Instructions.py
# Thomas Wise
# 17 July 2019

import os
import matplotlib.pyplot as plt
import statistics

def getIntVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit():
                started = True;
                val += x;
            elif x != "," and started:
                done = True;
    val = int(val);
    return val;

def getIntVal2(line):
    started1 = False;
    started2 = False;
    done1 = False;
    done2 = False;
    val = '';
    for x in line:
        if not done1:
            if x.isdigit():
                started1 = True;
            elif x != "," and x != "." and started1:
                done1 = True;
        elif not done2:
            if x.isdigit():
                started2 = True;
                val += x;
            elif x != "," and started2:
                done2 = True;
    if val == '':
        return getIntVal(line);
    val = int(val);
    return val;
    
def getFltVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit() or x == '.':
                val += x;
                started = True;
            elif x == ' ' and started:
                done = True;
    val = float(val);
    return val;
    
def parseFile(filename, taskClocks, contextSwitches, cpuMigrations, pageFaults,
                cycles, instructions, branches, branchMisses, runTimes, solver):
    solverNum = -1;
    if solver == "Glucose":
        solverNum = 0;
    elif solver == "Maple_CM":
        solverNum = 1;
    elif solver == "Maple_Glucose":
        solverNum = 2;
    elif solver == "MapleSat":
        solverNum = 3;
    elif solver == "MiniSat":
        solverNum = 4;
        
    f = open(filename);
    f1 = f.readlines();
    f.close();
    started = False;
    
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal2(line);
            started = True;
        elif "task-clock" in line and started:
            taskClocks[index][solverNum].append(getFltVal(line));
        elif "context-switches" in line and started:
            contextSwitches[index][solverNum].append(getIntVal(line));
        elif "cpu-migrations" in line and started:
            cpuMigrations[index][solverNum].append(getIntVal(line));
        elif "page-faults" in line and started:
            pageFaults[index][solverNum].append(getIntVal(line));
        elif "cycles" in line and not "instructions" in line and started:
            cycles[index][solverNum].append(getIntVal(line));
        elif "instructions" in line and started:
            instructions[index][solverNum].append(getIntVal(line));
        elif "branches" in line and not "misses" in line and started:
            branches[index][solverNum].append(getIntVal(line));
        elif "branch-misses" in line and started:
            branchMisses[index][solverNum].append(getIntVal(line));
        elif "seconds time elapsed" in line and started:
            runTimes[index][solverNum].append(getFltVal(line));
                

def makePlot(l, plot, start, end, size, dataType, solverNum):
    for instance in l[dataType]:
        if len(instance[solverNum]) == size:
            if statistics.mean(instance[solverNum]) != 0:
                plot.append(statistics.stdev(instance[solverNum]) / statistics.mean(instance[solverNum]));
            else:
                plot.append(0);

def getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes, solver):
    for filename in os.listdir(solver + "/Perf_Standard/Data/Results"):
        if "slurm" in filename or ".txt.e" in filename or ".out" in filename:
            parseFile(solver + "/Perf_Standard/Data/Results/" + filename, taskClocks,
                        contextSwitches, cpuMigrations, pageFaults,
                        cycles, instructions, branches, branchMisses, runTimes, solver);

start = 0;
end = 399;
instances = end - start + 1;
testsPerInstance = 10;

solvers = ["Glucose", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat"];

taskClocks = [];
contextSwitches = [];
cpuMigrations = [];
pageFaults = [];
cycles = [];
instructions = [];
branches = [];
branchMisses = [];
runTimes = [];

data = [taskClocks, contextSwitches, cpuMigrations, pageFaults,
        cycles, instructions, branches, branchMisses, runTimes];

for x in range(0, instances):
    for dataType in data:
        dataType.append([]);
        for poop in range(0,5):
            dataType[len(dataType) - 1].append([]);

taskClocksPlot = [];
contextSwitchesPlot = [];
cpuMigrationsPlot = [];
pageFaultsPlot = [];
cyclesPlot = [];
instructionsPlot = [];
branchesPlot = [];
branchMissesPlot = [];
runTimesPlot = [];   

glucosePlot = [];
mapleCMPlot = [];
mapleGlucosePlot = [];
mapleSatPlot = [];
miniSatPlot = [];

dataToPlot = [instructionsPlot, runTimesPlot];
solversToPlot = [glucosePlot, mapleCMPlot, mapleGlucosePlot, mapleSatPlot, miniSatPlot]
for solver in solvers:
    getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes, solver);
     

solverNum = 0;
for x in solversToPlot:
    makePlot(data, x, start, end, testsPerInstance, 5, solverNum);
    solverNum += 1;

fig = plt.figure(1, figsize=(9, 6));
ax = fig.add_subplot(111);
bp = ax.boxplot(solversToPlot);
ax.set_xticklabels(["Glucose", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat"]);
ax.set_yscale("log");
plt.ylabel("STDEV / Mean");
plt.xticks(rotation=20);
fig.show();
print(len(glucosePlot));