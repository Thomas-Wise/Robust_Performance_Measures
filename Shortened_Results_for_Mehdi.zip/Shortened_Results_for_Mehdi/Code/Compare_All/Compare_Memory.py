# Compare.py
# Thomas Wise
# 04 Aug 2019

import os
import matplotlib.pyplot as plt
import statistics

def getIntVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit():
                started = True;
                val += x;
            elif x != "," and started:
                done = True;
    val = int(val);
    return val;

def getIntVal2(line):
    started1 = False;
    started2 = False;
    done1 = False;
    done2 = False;
    val = '';
    for x in line:
        if not done1:
            if x.isdigit():
                started1 = True;
            elif x != "," and x != "." and started1:
                done1 = True;
        elif not done2:
            if x.isdigit():
                started2 = True;
                val += x;
            elif x != "," and started2:
                done2 = True;
    if val == '':
        return getIntVal(line);
    val = int(val);
    return val;
    
def getFltVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit() or x == '.':
                val += x;
                started = True;
            elif x == ' ' and started:
                done = True;
    val = float(val);
    return val;
    
def parseFile(filename, taskClocks, contextSwitches, cpuMigrations, pageFaults,
                cycles, instructions, branches, branchMisses, runTimes,
                all_stores, all_loads, solver):
    solverNum = -1;
    if solver == "Glucose":
        solverNum = 0;
    elif solver == "Maple_CM":
        solverNum = 1;
    elif solver == "Maple_Glucose":
        solverNum = 2;
    elif solver == "MapleSat":
        solverNum = 3;
    elif solver == "MiniSat":
        solverNum = 4;
        
    f = open(filename);
    f1 = f.readlines();
    f.close();
    started = False;
    
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal2(line);
            started = True;
        elif "task-clock" in line and started:
            taskClocks[index][solverNum].append(getFltVal(line));
        elif "context-switches" in line and started:
            contextSwitches[index][solverNum].append(getIntVal(line));
        elif "cpu-migrations" in line and started:
            cpuMigrations[index][solverNum].append(getIntVal(line));
        elif "page-faults" in line and started:
            pageFaults[index][solverNum].append(getIntVal(line));
        elif "cycles" in line and not "instructions" in line and started:
            cycles[index][solverNum].append(getIntVal(line));
        elif "instructions" in line and started:
            instructions[index][solverNum].append(getIntVal(line));
        elif "branches" in line and not "misses" in line and started:
            branches[index][solverNum].append(getIntVal(line));
        elif "branch-misses" in line and started:
            branchMisses[index][solverNum].append(getIntVal(line));
        elif "seconds time elapsed" in line and started:
            runTimes[index][solverNum].append(getFltVal(line));
        elif "mem_uops_retired.all_stores" in line and started:
            all_stores[index][solverNum].append(getIntVal(line));
        elif "mem_uops_retired.all_loads" in line and started:
            all_loads[index][solverNum].append(getIntVal(line));
    print(filename);
                

def makePlot(data, knldata, plot, start, end, size, dataType, solverNum):
    
    for instance in range(0, len(data[dataType])):
        if len(data[dataType][instance][solverNum]) == size and len(knldata[dataType][instance][solverNum]) == size:
            if statistics.mean(data[dataType][instance][solverNum]) != 0 and statistics.mean(knldata[dataType][instance][solverNum]) != 0:
                plot.append(statistics.mean(knldata[dataType][instance][solverNum]) / statistics.mean(data[dataType][instance][solverNum]));
            else:
                plot.append(0);

def getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes,
            all_stores, all_loads, solver):
    for filename in os.listdir(solver + "/Perf_MEM_UOPS_RETIRED/Data/Results"):
        if "slurm" in filename or ".txt.e" in filename or ".out" in filename:
            parseFile(solver + "/Perf_MEM_UOPS_RETIRED/Data/Results/" + filename, taskClocks,
                        contextSwitches, cpuMigrations, pageFaults,
                        cycles, instructions, branches, branchMisses, runTimes,
                        all_stores, all_loads, solver);
                        
def knlgetData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes,
            all_stores, all_loads, solver):
    for filename in os.listdir(solver + "/Perf_MEM_UOPS_RETIRED/Data/knlResults"):
        if "slurm" in filename or ".txt.e" in filename or ".out" in filename:
            parseFile(solver + "/Perf_MEM_UOPS_RETIRED/Data/knlResults/" + filename, taskClocks,
                        contextSwitches, cpuMigrations, pageFaults,
                        cycles, instructions, branches, branchMisses, runTimes,
                        all_stores, all_loads, solver);

start = 0;
end = 399;
instances = end - start + 1;
testsPerInstance = 10;

solvers = ["Glucose", "Maple_CM", "Maple_Glucose", "MapleSat", "MiniSat"];

taskClocks = [];
contextSwitches = [];
cpuMigrations = [];
pageFaults = [];
cycles = [];
instructions = [];
branches = [];
branchMisses = [];
runTimes = [];
all_stores = [];
all_loads = [];
all_stores_and_loads = [];

knltaskClocks = [];
knlcontextSwitches = [];
knlcpuMigrations = [];
knlpageFaults = [];
knlcycles = [];
knlinstructions = [];
knlbranches = [];
knlbranchMisses = [];
knlrunTimes = [];
knlall_stores = [];
knlall_loads = [];
knlall_stores_and_loads = [];

data = [taskClocks, contextSwitches, cpuMigrations, pageFaults,
        cycles, instructions, branches, branchMisses, runTimes,
        all_stores, all_loads, all_stores_and_loads];
        
knldata = [knltaskClocks, knlcontextSwitches, knlcpuMigrations, knlpageFaults,
        knlcycles, knlinstructions, knlbranches, knlbranchMisses, knlrunTimes,
        knlall_stores, knlall_loads, knlall_stores_and_loads];

for x in range(0, instances):
    for dataType in data:
        dataType.append([]);
        for poop in range(0,5):
            dataType[len(dataType) - 1].append([]);
    for dataType in knldata:
        dataType.append([]);
        for poop in range(0,5):
            dataType[len(dataType) - 1].append([]);

taskClocksPlot = [];
contextSwitchesPlot = [];
cpuMigrationsPlot = [];
pageFaultsPlot = [];
cyclesPlot = [];
instructionsPlot = [];
branchesPlot = [];
branchMissesPlot = [];
runTimesPlot = [];
all_storesPlot = [];
all_loadsPlot = [];
all_stores_and_loadsPlot = [];

glucosePlot = [];
mapleCMPlot = [];
mapleGlucosePlot = [];
mapleSatPlot = [];
miniSatPlot = [];

for x in range(0, 5):
    all_storesPlot.append([]);
    all_loadsPlot.append([]);
    all_stores_and_loadsPlot.append([]);
    instructionsPlot.append([]);

dataToPlot = [];
for x in range(0, 5):
    dataToPlot.append(all_storesPlot[x]);
    dataToPlot.append(all_loadsPlot[x]);
    dataToPlot.append(all_stores_and_loadsPlot[x]);
    dataToPlot.append(instructionsPlot[x]);

solversToPlot = [glucosePlot, mapleCMPlot, mapleGlucosePlot, mapleSatPlot, miniSatPlot];

for solver in solvers:
    getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes,
            all_stores, all_loads, solver);
    knlgetData(knltaskClocks, knlcontextSwitches, knlcpuMigrations, knlpageFaults,
            knlcycles, knlinstructions, knlbranches, knlbranchMisses, knlrunTimes,
            knlall_stores, knlall_loads, solver);
"""
getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
        cycles, instructions, branches, branchMisses, runTimes,
        all_stores, all_loads, "Glucose");
knlgetData(knltaskClocks, knlcontextSwitches, knlcpuMigrations, knlpageFaults,
        knlcycles, knlinstructions, knlbranches, knlbranchMisses, knlrunTimes,
        knlall_stores, knlall_loads, "Glucose");
"""
    
index = 0;
for instance in all_stores_and_loads:
    index2 = 0;
    for solver in instance:
        index3 = 0;
        for test in all_stores[index][index2]:
            solver.append(all_stores[index][index2][index3] + all_loads[index][index2][index3])
            index3 += 1;
        index2 += 1;
    index += 1;
    
index = 0;
for instance in knlall_stores_and_loads:
    index2 = 0;
    for solver in instance:
        index3 = 0;
        for test in knlall_stores[index][index2]:
            solver.append(knlall_stores[index][index2][index3] + knlall_loads[index][index2][index3])
            index3 += 1;
        index2 += 1;
    index += 1;
    

print(instructions);
print(all_stores_and_loads);

for x in range(0, 5):
    makePlot(data, knldata, instructionsPlot[x], start, end, testsPerInstance, 5, x);
    makePlot(data, knldata, all_loadsPlot[x], start, end, testsPerInstance, 10, x);
    makePlot(data, knldata, all_storesPlot[x], start, end, testsPerInstance, 9, x);
    makePlot(data, knldata, all_stores_and_loadsPlot[x], start, end, testsPerInstance, 11, x);

"""
solverNum = 0;
for x in solversToPlot:
    makePlot(data, knldata, x, start, end, testsPerInstance, 9, solverNum);
    solverNum += 1;
"""

fig = plt.figure(1, figsize=(9, 6));
ax = fig.add_subplot(111);
bp = ax.boxplot(dataToPlot);
ax.set_xticklabels(["Glucose_all_stores", "Glucose_all_loads", "Glucose_all_stores_and_loads", "Glucose_instructions",
                    "Maple_CM_all_stores", "Maple_CM_all_loads", "Maple_CM_all_stores_and_loads", "Maple_CM_instructions",
                    "Maple_Glucose_all_stores", "Maple_Glucose_all_loads", "Maple_Glucose_all_stores_and_loads", "Maple_Glucose_instructions",
                    "MapleSat_all_stores", "MapleSat_all_loads", "MapleSat_all_stores_and_loads", "MapleSat_instructions",
                    "MiniSat_all_stores", "MiniSat_all_loads", "MiniSat_all_stores_and_loads", "MiniSat_instructions"]);
ax.set_yscale("linear");
plt.ylabel("knl-Mean / Teton-Mean");
plt.xticks(rotation=20);
fig.show();
print(len(glucosePlot));