# CreateBoxPlots_knl.py
# Thomas Wise
# 15 Sep 2019

import os
import matplotlib.pyplot as plt
import statistics

def getIntVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit():
                started = True;
                val += x;
            elif x != "," and started:
                done = True;
    if val == '':
        return -1;
    val = int(val);
    return val;

def getIntVal2(line):
    started1 = False;
    started2 = False;
    done1 = False;
    done2 = False;
    val = '';
    for x in line:
        if not done1:
            if x.isdigit():
                started1 = True;
            elif x != "," and x != "." and started1:
                done1 = True;
        elif not done2:
            if x.isdigit():
                started2 = True;
                val += x;
            elif x != "," and started2:
                done2 = True;
    if val == '':
        return getIntVal(line);
    val = int(val);
    return val;
    
def getFltVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit() or x == '.':
                val += x;
                started = True;
            elif x == ' ' and started:
                done = True;
    if val == '':
        return -1;
    val = float(val);
    return val;
    
def parseFile(filename, all_stores, all_loads, instructions, runTimes):
    tmpAll_stores = -1;
    tmpAll_loads = -1;
    tmpInstructions = -1;
    tmpRunTime = -1;
    f = open(filename);
    f1 = f.readlines();
    f.close();
    started = False;
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal(line);
            started = True;
        elif "mem_uops_retired.all_stores" in line and started:
            tmpAll_stores = getIntVal(line);
            #print("dCacheLoads: " + str(tmpDCacheLoads));
        elif "mem_uops_retired.all_loads" in line and started:
            tmpAll_loads = getIntVal(line);
            #print("dCacheLoadMisses: " + str(tmpDCacheLoadMisses));
        elif "instructions" in line and started:
            tmpInstructions = getIntVal(line);
            #print("instructions: " + str(tmpInstructions));
        elif "seconds time elapsed" in line and started:
            tmpRunTime = getFltVal(line);
            #print("runTime: " + str(tmpRunTime));
    if (tmpAll_stores != -1 and tmpAll_loads != -1
        and tmpInstructions != -1 and tmpRunTime != -1):
        #print("not broken");
        all_stores[index].append(tmpAll_stores);
        all_loads[index].append(tmpAll_loads);
        instructions[index].append(tmpInstructions);
        runTimes[index].append(tmpRunTime);
    #else:
      #  print("broken");
    print(filename);
                

def makePlot(l, plot, start, end, size):
    for instance in l:
        if len(instance) == size:
            if statistics.mean(instance) != 0:
                plot.append(statistics.stdev(instance) / statistics.mean(instance));
            else:
                plot.append(0);

def getData(all_stores, all_loads, instructions, runTimes):
    for filename in os.listdir("knlResults"):
        if ".out" in filename:
            parseFile("knlResults/" + filename, all_stores, all_loads, instructions, runTimes);

start = 0;
end = 399;
instances = end - start + 1;
testsPerInstance = 10;



all_stores = [];
all_loads = [];
instructions = [];
runTimes = [];

data = [all_stores, all_loads, instructions, runTimes];

for x in range(0, instances):
    for dataType in data:
        dataType.append([]);

all_storesPlot = [];
all_loadsPlot = [];
instructionsPlot = [];
runTimesPlot = [];

   

dataToPlot = [all_storesPlot, all_loadsPlot, instructionsPlot, runTimesPlot];

getData(all_stores, all_loads, instructions, runTimes);
     

index = 0;
for x in dataToPlot:
    makePlot(data[index], x, start, end, testsPerInstance);
    index += 1;

fig = plt.figure(1, figsize=(9, 6));
ax = fig.add_subplot(111);
bp = ax.boxplot(dataToPlot);
ax.set_xticklabels(["all_stores", "all_loads", "instructions", "runTimes"]);
ax.set_yscale("log");
plt.ylabel("STDEV / Mean");
plt.xticks(rotation=20);
fig.show();
print(len(runTimesPlot));