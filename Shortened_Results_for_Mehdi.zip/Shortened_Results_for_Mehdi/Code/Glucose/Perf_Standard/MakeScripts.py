# MakeScripts.py
# Thomas Wise
# 22 June 2019

import os

def makeScript(instanceNum, testNum, inc):
    instanceStr = '';
    incStr = '';
    if instanceNum < 10:
        instanceStr += '0';
    if instanceNum < 100:
        instanceStr += '0';
    instanceStr += str(instanceNum);
    
    """if inc < 10:
        incStr += '0';
    if inc < 100:
        incStr += '0';
    if inc < 1000:
        incStr +='0';
    """
    incStr += str(inc);
    
    filename = '';
    filename += incStr + '.txt';
    f = open("Scripts/" + filename, "w+", newline = "\n");
    f.write("#!/bin/sh\n");
    f.write("#PBS -l walltime=02:00:00\n");
    f.write("#PBS -l nodes=1:ppn=1\n");
    f.write("#PBS -N GlucoseInstance" + instanceStr + "Test" + str(testNum) + "\n");
    f.write("#PBS -A mallet\n");
    f.write("cd\n");
    f.write("cd Sat\n");
    f.write("perf stat ./Glucose/glucose_static Instances/inst" + instanceStr + ".cnf");
    f.close();
    
inc = 0;
instanceNum = 0;
for instance in range(0, 400):
    for testNum in range(0, 10):
        makeScript(instanceNum, testNum, inc);
        inc += 1;
    instanceNum += 1;