# CreateBoxPlots_InstructionsAndRuntime.py
# Thomas Wise
# 07 July 2019

import os
import matplotlib.pyplot as plt
import statistics

def getIntVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit():
                started = True;
                val += x;
            elif x != "," and started:
                done = True;
    val = int(val);
    return val;

def getIntVal2(line):
    started1 = False;
    started2 = False;
    done1 = False;
    done2 = False;
    val = '';
    for x in line:
        if not done1:
            if x.isdigit():
                started1 = True;
            elif x != "," and x != "." and started1:
                done1 = True;
        elif not done2:
            if x.isdigit():
                started2 = True;
                val += x;
            elif x != "," and started2:
                done2 = True;
    val = int(val);
    return val;

def getFltVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit() or x == '.':
                val += x;
                started = True;
            elif x == ' ' and started:
                done = True;
    val = float(val);
    return val;
    
def parseFile(filename, instructions, runTimes):
    f = open(filename);
    f1 = f.readlines();
    f.close();
    started = False;
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal(line);
            started = True;
        if "seconds time elapsed" in line and started:
            runTimes[index].append(getFltVal(line));
        if "instructions" in line and started:
            instructions[index].append(getIntVal(line));
            
def makePlot(l, plot, start, end, size):
    inc = 0;
    for instance in l:
        if len(instance) == size:
            plot.append(statistics.stdev(instance) / statistics.mean(instance));
            if plot[len(plot) - 1] > 0.25:
                print(inc);
        inc += 1;

def getData(instructions, runTimes):
    inc = 0;
    for filename in os.listdir("knlResults"):
        if "slurm" in filename:
            parseFile("knlResults/" + filename, instructions, runTimes);
            print(inc);
            inc += 1;

start = 0;
end = 399;
instances = end - start + 1;
testsPerInstance = 10;

instructions = [];
runTimes = [];
for x in range(0, instances):
    instructions.append([]);
    runTimes.append([]);
instructionsPlot = [];
runTimesPlot = [];

getData(instructions, runTimes);

inc = 0;

makePlot(instructions, instructionsPlot, start, end, testsPerInstance);
makePlot(runTimes, runTimesPlot, start, end, testsPerInstance);

dataToPlot = [instructionsPlot, runTimesPlot];
fig = plt.figure(1, figsize=(9, 6));
ax = fig.add_subplot(111);
bp = ax.boxplot(dataToPlot);
ax.set_xticklabels(["instructions", "runTime"]);
plt.xticks(rotation=20);
fig.show();

print(len(instructionsPlot));
print(len(runTimesPlot));