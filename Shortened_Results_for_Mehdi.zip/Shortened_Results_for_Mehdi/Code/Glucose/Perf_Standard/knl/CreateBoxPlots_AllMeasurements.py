# CreateBoxPlots_InstructionsAndRuntime.py
# Thomas Wise
# 07 July 2019

import os
import matplotlib.pyplot as plt
import statistics

def getIntVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit():
                started = True;
                val += x;
            elif x != "," and started:
                done = True;
    val = int(val);
    return val;

def getIntVal2(line):
    started1 = False;
    started2 = False;
    done1 = False;
    done2 = False;
    val = '';
    for x in line:
        if not done1:
            if x.isdigit():
                started1 = True;
            elif x != "," and x != "." and started1:
                done1 = True;
        elif not done2:
            if x.isdigit():
                started2 = True;
                val += x;
            elif x != "," and started2:
                done2 = True;
    if val == '':
        return getIntVal(line);
    val = int(val);
    return val;
    
def getFltVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit() or x == '.':
                val += x;
                started = True;
            elif x == ' ' and started:
                done = True;
    val = float(val);
    return val;
    
def parseFile(filename, taskClocks, contextSwitches, cpuMigrations, pageFaults,
                cycles, instructions, branches, branchMisses, runTimes):
    
    f = open(filename);
    f1 = f.readlines();
    f.close();
    started = False;
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal(line);
            started = True;
        elif "task-clock" in line and started:
            taskClocks[index].append(getFltVal(line));
        elif "context-switches" in line and started:
            contextSwitches[index].append(getIntVal(line));
        elif "cpu-migrations" in line and started:
            cpuMigrations[index].append(getIntVal(line));
        elif "page-faults" in line and started:
            pageFaults[index].append(getIntVal(line));
        elif "cycles" in line and not "instructions" in line and started:
            cycles[index].append(getIntVal(line));
        elif "instructions" in line and started:
            instructions[index].append(getIntVal(line));
        elif "branches" in line and not "misses" in line and started:
            branches[index].append(getIntVal(line));
        elif "branch-misses" in line and started:
            branchMisses[index].append(getIntVal(line));
        elif "seconds time elapsed" in line and started:
            runTimes[index].append(getFltVal(line));
                

def makePlot(l, plot, start, end, size):
    for instance in l:
        if len(instance) == size:
            if statistics.mean(instance) != 0:
                plot.append(statistics.stdev(instance) / statistics.mean(instance));
            else:
                plot.append(0);

def getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes):
    for filename in os.listdir("knlResults"):
        if "slurm" in filename:
            parseFile("knlResults/" + filename, taskClocks, contextSwitches, cpuMigrations, pageFaults,
                        cycles, instructions, branches, branchMisses, runTimes);

start = 0;
end = 399;
instances = end - start + 1;
testsPerInstance = 10;

#instructions = [];
#runTimes = [];

taskClocks = [];
contextSwitches = [];
cpuMigrations = [];
pageFaults = [];
cycles = [];
instructions = [];
branches = [];
branchMisses = [];
runTimes = [];

data = [taskClocks, contextSwitches, cpuMigrations, pageFaults,
        cycles, instructions, branches, branchMisses, runTimes];

for x in range(0, instances):
    for dataType in data:
        dataType.append([]);

taskClocksPlot = [];
contextSwitchesPlot = [];
cpuMigrationsPlot = [];
pageFaultsPlot = [];
cyclesPlot = [];
instructionsPlot = [];
branchesPlot = [];
branchMissesPlot = [];
runTimesPlot = [];    

dataToPlot = [taskClocksPlot, contextSwitchesPlot, cpuMigrationsPlot,
              pageFaultsPlot, cyclesPlot, instructionsPlot,
              branchesPlot, branchMissesPlot, runTimesPlot];

getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
        cycles, instructions, branches, branchMisses, runTimes);
     

index = 0;
for x in dataToPlot:
    makePlot(data[index], x, start, end, testsPerInstance);
    index += 1;

fig = plt.figure(1, figsize=(9, 6));
ax = fig.add_subplot(111);
bp = ax.boxplot(dataToPlot);
ax.set_xticklabels(["taskClocks", "contextSwitches", "cpuMigrations",
                    "pageFaults", "cycles", "instructions",
                    "branches", "branchMisses", "runTimes"]);
plt.xticks(rotation=20);
fig.show();
print(len(runTimesPlot));