# CreateBoxPlots_InstructionsAndRuntime.py
# Thomas Wise
# 16 June 2019

import os
import matplotlib.pyplot as plt
import statistics

def getIntVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit():
                started = True;
                val += x;
            elif x != "," and started:
                done = True;
    val = int(val);
    return val;

def getIntVal2(line):
    started1 = False;
    started2 = False;
    done1 = False;
    done2 = False;
    val = '';
    for x in line:
        if not done1:
            if x.isdigit():
                started1 = True;
            elif x != "," and x != "." and started1:
                done1 = True;
        elif not done2:
            if x.isdigit():
                started2 = True;
                val += x;
            elif x != "," and started2:
                done2 = True;
    if val == '':
        return getIntVal(line);
    val = int(val);
    return val;
    
def getFltVal(line):
    started = False;
    done = False;
    val = '';
    for x in line:
        if not done:
            if x.isdigit() or x == '.':
                val += x;
                started = True;
            elif x == ' ' and started:
                done = True;
    val = float(val);
    return val;
    
def parseFile(filename, taskClocks, contextSwitches, cpuMigrations, pageFaults,
                cycles, instructions, branches, branchMisses, runTimes):
    
    f = open(filename);
    f1 = f.readlines();
    f.close();
    for line in f1:
        if "Killed" in line or "PARSE ERROR" in line or "WARNING! DIMACS"  in line or "Bus error" in line:
            return;
        if "Performance counter stats for" in line:
            index = getIntVal(line);
        elif "task-clock" in line:
            taskClocks[index].append(getFltVal(line));
        elif "context-switches" in line:
            contextSwitches[index].append(getIntVal(line));
        elif "cpu-migrations" in line:
            cpuMigrations[index].append(getIntVal(line));
        elif "page-faults" in line:
            pageFaults[index].append(getIntVal(line));
        elif "cycles" in line and not "instructions" in line:
            cycles[index].append(getIntVal(line));
        elif "instructions" in line:
            instructions[index].append(getIntVal(line));
        elif "branches" in line and not "misses" in line:
            branches[index].append(getIntVal(line));
        elif "branch-misses" in line:
            branchMisses[index].append(getIntVal(line));
        elif "seconds time elapsed" in line:
            runTimes[index].append(getFltVal(line));
        
        """       
    F = open("Results/" + str(getIntVal(filename)) + ".txt.o" + str(getIntVal2(filename)));
    F1 = F.readlines();
    F.close();
    for line in F1:
        if "Number of variables" in line:
            if getIntVal(line) == 0:
                data = [taskClocks, contextSwitches, cpuMigrations, pageFaults,
                        cycles, instructions, branches, branchMisses, runTimes];
                for dataType in data:
                    dataType[index].pop(len(dataType[index]) - 1);
            return;
        """
                

def makePlot(l, plot, start, end, size):
    for instance in l:
        if len(instance) == size:
            plot.append(statistics.stdev(instance) / statistics.mean(instance));
            """
            high = instance[0];
            low = instance[0];
            for test in instance:
                if test > high:
                    high = test;
                if test < low:
                    low = test;
            Diff = (high - low) / high;
            plot.append(Diff)
            """;

def getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
            cycles, instructions, branches, branchMisses, runTimes):
    for filename in os.listdir("Results"):
        if "txt.e" in filename:
            parseFile("Results/" + filename, taskClocks, contextSwitches, cpuMigrations, pageFaults,
                        cycles, instructions, branches, branchMisses, runTimes);

start = 0;
end = 399;
instances = end - start + 1;
testsPerInstance = 10;

#instructions = [];
#runTimes = [];

taskClocks = [];
contextSwitches = [];
cpuMigrations = [];
pageFaults = [];
cycles = [];
instructions = [];
branches = [];
branchMisses = [];
runTimes = [];

data = [taskClocks, contextSwitches, cpuMigrations, pageFaults,
        cycles, instructions, branches, branchMisses, runTimes];

for x in range(0, instances):
    for dataType in data:
        dataType.append([]);

taskClocksPlot = [];
contextSwitchesPlot = [];
cpuMigrationsPlot = [];
pageFaultsPlot = [];
cyclesPlot = [];
instructionsPlot = [];
branchesPlot = [];
branchMissesPlot = [];
runTimesPlot = [];    

dataToPlot = [taskClocksPlot, contextSwitchesPlot, cpuMigrationsPlot,
              pageFaultsPlot, cyclesPlot, instructionsPlot,
              branchesPlot, branchMissesPlot, runTimesPlot];

getData(taskClocks, contextSwitches, cpuMigrations, pageFaults,
        cycles, instructions, branches, branchMisses, runTimes);
     

index = 0;
for x in dataToPlot:
    makePlot(data[index], x, start, end, testsPerInstance);
    index += 1;

fig = plt.figure(1, figsize=(9, 6));
ax = fig.add_subplot(111);
bp = ax.boxplot(dataToPlot);
ax.set_xticklabels(["taskClocks", "contextSwitches", "cpuMigrations",
                    "pageFaults", "cycles", "instructions",
                    "branches", "branchMisses", "runTimes"]);
plt.xticks(rotation=20);
fig.show();
print(len(runTimesPlot));